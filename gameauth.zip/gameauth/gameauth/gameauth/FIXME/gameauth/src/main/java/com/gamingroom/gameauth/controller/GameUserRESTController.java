package com.gamingroom.gameauth.controller;

import io.dropwizard.auth.Auth;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Set;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.gamingroom.gameauth.auth.GameUser;
import com.gamingroom.gameauth.dao.GameUserDB;
import com.gamingroom.gameauth.representations.GameUserInfo;

/**
 * REST Controller for managing Game Users.
 */
@Produces(MediaType.APPLICATION_JSON)
@Path("/gameusers") // Added path annotation for gameusers
public class GameUserRESTController {

    private final Validator validator;

    /**
     * Constructor to initialize the controller with a validator.
     * 
     * @param validator Validator for GameUserInfo objects.
     */
    public GameUserRESTController(Validator validator) {
        this.validator = validator;
    }

    /**
     * Fetches all game users.
     * 
     * @param user Authenticated user making the request.
     * @return Response containing the list of all game users.
     */
    @PermitAll
    @GET
    public Response getGameUsers(@Auth GameUser user) {
        return Response.ok(GameUserDB.getGameUsers()).build();
    }

    /**
     * Fetches a specific game user by ID.
     * 
     * @param id   The ID of the game user.
     * @param user Authenticated user making the request.
     * @return Response containing the game user or NOT_FOUND if not found.
     */
    @RolesAllowed("USER") // Added RolesAllowed annotation for USER
    @GET
    @Path("/{id}")
    public Response getGameUserById(@PathParam("id") Integer id, @Auth GameUser user) {
        GameUserInfo gameUserInfo = GameUserDB.getGameUser(id);
        if (gameUserInfo != null) {
            return Response.ok(gameUserInfo).build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    /**
     * Creates a new game user.
     * 
     * @param gameUserInfo GameUserInfo object containing user details.
     * @param user         Authenticated user making the request.
     * @return Response indicating the status of creation.
     * @throws URISyntaxException If the URI syntax is incorrect.
     */
    @RolesAllowed("ADMIN") // Added RolesAllowed annotation for ADMIN
    @POST
    public Response createGameUser(GameUserInfo gameUserInfo, @Auth GameUser user) throws URISyntaxException {
        // Validate GameUserInfo object
        Set<ConstraintViolation<GameUserInfo>> violations = validator.validate(gameUserInfo);
        if (!violations.isEmpty()) {
            ArrayList<String> validationMessages = new ArrayList<>();
            for (ConstraintViolation<GameUserInfo> violation : violations) {
                validationMessages.add(violation.getPropertyPath().toString() + ": " + violation.getMessage());
            }
            return Response.status(Status.BAD_REQUEST).entity(validationMessages).build();
        }

        // Check if user already exists
        GameUserInfo existingUser = GameUserDB.getGameUser(gameUserInfo.getId());
        if (existingUser == null) {
            GameUserDB.addGameUser(gameUserInfo);
            return Response.created(new URI("/gameusers/" + gameUserInfo.getId())).build();
        } else {
            return Response.status(Status.CONFLICT).entity("User already exists.").build();
        }
    }

    /**
     * Updates an existing game user by ID.
     * 
     * @param id           The ID of the game user.
     * @param gameUserInfo GameUserInfo object containing updated details.
     * @return Response indicating the status of the update.
     */
    @RolesAllowed("ADMIN") // Added RolesAllowed annotation for ADMIN
    @PUT
    @Path("/{id}")
    public Response updateGameUserById(@PathParam("id") Integer id, GameUserInfo gameUserInfo) {
        // Validate GameUserInfo object
        Set<ConstraintViolation<GameUserInfo>> violations = validator.validate(gameUserInfo);
        if (!violations.isEmpty()) {
            ArrayList<String> validationMessages = new ArrayList<>();
            for (ConstraintViolation<GameUserInfo> violation : violations) {
                validationMessages.add(violation.getPropertyPath().toString() + ": " + violation.getMessage());
            }
            return Response.status(Status.BAD_REQUEST).entity(validationMessages).build();
        }

        // Check if user exists and update details
        GameUserInfo existingUser = GameUserDB.getGameUser(gameUserInfo.getId());
        if (existingUser != null) {
            gameUserInfo.setId(id);
            GameUserDB.updateGameUser(id, gameUserInfo);
            return Response.ok(gameUserInfo).build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    /**
     * Deletes a game user by ID.
     * 
     * @param id The ID of the game user.
     * @return Response indicating the status of the deletion.
     */
    @RolesAllowed("ADMIN") // Added RolesAllowed annotation for ADMIN
    @DELETE
    @Path("/{id}")
    public Response removeGameUserById(@PathParam("id") Integer id) {
        GameUserInfo gameUserInfo = GameUserDB.getGameUser(id);
        if (gameUserInfo != null) {
            GameUserDB.removeGameUser(id);
            return Response.ok().build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }
}
