package com.gamingroom.gameauth.dao;

import java.util.HashMap;
import java.util.Map;

import com.gamingroom.gameauth.representations.GameUserInfo;

public class GameUserDB {
    // Initialize userDB with static test data
    private static Map<Integer, GameUserInfo> userDB = new HashMap<>();

    static {
        // Add some default users to the database
        userDB.put(1, new GameUserInfo(1, "Lokesh", "Gupta", "India"));
        userDB.put(2, new GameUserInfo(2, "John", "Gruber", "USA"));
        userDB.put(3, new GameUserInfo(3, "Melcum", "Marshal", "AUS"));
    }

    // Get a user by ID
    public static GameUserInfo getGameUser(int id) {
        return userDB.get(id);
    }

    // Get all users
    public static Map<Integer, GameUserInfo> getGameUsers() {
        return userDB;
    }

    // Add a new user
    public static void addGameUser(GameUserInfo userInfo) {
        userDB.put(userInfo.getId(), userInfo);
    }

    // Update an existing user
    public static void updateGameUser(int id, GameUserInfo userInfo) {
        userDB.put(id, userInfo);
    }

    // Remove a user
    public static void removeGameUser(int id) {
        userDB.remove(id);
    }
}
