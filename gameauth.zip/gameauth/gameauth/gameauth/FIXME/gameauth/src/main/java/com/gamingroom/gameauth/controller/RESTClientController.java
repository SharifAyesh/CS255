package com.gamingroom.gameauth.controller;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gamingroom.gameauth.representations.GameUserInfo;

/**
 * REST client controller to interact with game users.
 */
@Produces(MediaType.TEXT_PLAIN)
@Path("/client")
public class RESTClientController {

    private final Client client;

    /**
     * Constructor for the RESTClientController.
     *
     * @param client The JAX-RS client used for making HTTP requests.
     */
    public RESTClientController(Client client) {
        this.client = client;
    }

    /**
     * Fetches all game users.
     *
     * @return A list of game users in string format.
     */
    @GET
    @Path("/gameusers")
    public String getGameUsers() {
        // Replace hardcoded URL with a configurable endpoint in production
        WebTarget webTarget = client.target("http://localhost:8080/gameusers");
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        Response response = invocationBuilder.get();
        ArrayList<?> gameusers = response.readEntity(ArrayList.class);
        return gameusers.toString();
    }

    /**
     * Fetches a specific game user by ID.
     *
     * @param id The ID of the game user to fetch.
     * @return The game user's details in string format.
     */
    @GET
    @Path("/gameusers/{id}")
    public String getGameUserById(@PathParam("id") int id) {
        // Replace hardcoded URL with a configurable endpoint in production
        WebTarget webTarget = client.target("http://localhost:8080/gameusers/" + id);
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        Response response = invocationBuilder.get();
        GameUserInfo gameUserInfo = response.readEntity(GameUserInfo.class);
        return gameUserInfo.toString();
    }
}
