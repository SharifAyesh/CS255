package com.gamingroom.gameauth;

import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

import javax.ws.rs.client.Client;

import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamingroom.gameauth.auth.GameAuthenticator;
import com.gamingroom.gameauth.auth.GameAuthorizer;
import com.gamingroom.gameauth.auth.GameUser;

import com.gamingroom.gameauth.controller.GameUserRESTController;
import com.gamingroom.gameauth.controller.RESTClientController;

import com.gamingroom.gameauth.healthcheck.AppHealthCheck;

public class GameAuthApplication extends Application<Configuration> {
    private static final Logger LOGGER = LoggerFactory.getLogger(GameAuthApplication.class);

    @Override
    public void initialize(Bootstrap<Configuration> bootstrap) {
        // No specific initialization required
    }

    @Override
    public void run(Configuration configuration, Environment environment) throws Exception {
        LOGGER.info("Registering REST resources");

        // Step 1: Configure and create a JerseyClientBuilder instance
        JerseyClientConfiguration clientConfig = new JerseyClientConfiguration();
        // Customize client settings if needed (timeouts, etc.)
        clientConfig.setTimeout(io.dropwizard.util.Duration.seconds(5));  // Example customization
        Client client = new JerseyClientBuilder(environment)
                .using(clientConfig)
                .build("GameAuthRESTClient");

        // Step 2: Register REST controllers
        environment.jersey().register(new GameUserRESTController(environment.getValidator()));
        environment.jersey().register(new RESTClientController(client));

        // Step 3: Add Application Health Check
        environment.healthChecks().register("APIHealthCheck", new AppHealthCheck(client));

        // Step 4: Add Basic Security using Authenticator and Authorizer
        environment.jersey().register(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<GameUser>()
                .setAuthenticator(new GameAuthenticator())
                .setAuthorizer(new GameAuthorizer())
                .setRealm("GameAuthRealm")
                .buildAuthFilter()));
        environment.jersey().register(new AuthValueFactoryProvider.Binder<>(GameUser.class));
        environment.jersey().register(RolesAllowedDynamicFeature.class);

        LOGGER.info("Application started successfully");
    }

    public static void main(String[] args) throws Exception {
        new GameAuthApplication().run(args);
    }
}
