package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

/**
 * Handles role-based authorization for Game Users.
 */
public class GameAuthorizer implements Authorizer<GameUser> {

    /**
     * Authorizes a user based on their role.
     *
     * @param user The authenticated user.
     * @param role The required role for accessing the resource.
     * @return true if the user is authorized, false otherwise.
     */
    @Override
    public boolean authorize(GameUser user, String role) {
        // Check if the user and their roles are not null
        if (user != null && user.getRoles() != null) {
            // Check if the user has the required role
            return user.getRoles().contains(role);
        }
        return false; // Return false if the user or roles are null
    }
}
